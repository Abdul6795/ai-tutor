from fastapi import FastAPI, File, UploadFile, Form
from fastapi.responses import JSONResponse
from app.utils import extract_text_from_pdf, answer_question,ask_gpt
import fitz
import openai
import os
from dotenv import load_dotenv

load_dotenv()

openai.api_key=os.getenv("OPENAI_API_KEY")

app = FastAPI()

# Store extracted text for the session
pdf_text_store = {}

@app.post("/upload-book/")
async def upload_book(file: UploadFile = File(...)):
    """Endpoint to upload a PDF file and extract text from it."""
    file_location = f"./{file.filename}"
    with open(file_location, "wb") as f:
        f.write(await file.read())

    # Extract text from the PDF
    book_text = extract_text_from_pdf(file_location)
    
    # Store the cleaned text in memory
    pdf_text_store[file.filename] = book_text

    return {"message": "Book uploaded and text extracted.", "book_text": book_text[:200]}  # Show first 200 characters

@app.post("/ask-questions/")
async def ask_question(question: str = Form(...), file_name: str = Form(...)):
    """Endpoint to ask a question based on the uploaded PDF content."""
    if file_name not in pdf_text_store:
        return JSONResponse(content={"error": "Book not found. Please upload the book first."}, status_code=404)
    
    # Get the extracted text from the PDF
    book_text = pdf_text_store[file_name]
    
    # Generate the answer using the model
    answer = answer_question(question, book_text)

    return {"answer": answer}


# @app.post("/ask-questions/")
# async def ask_question(question: str=Form(...),context: str = Form(None)):

#     answer=ask_gpt(question,context)
#     return {'answer':answer}