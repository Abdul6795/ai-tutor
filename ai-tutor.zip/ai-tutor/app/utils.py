import fitz  # PyMuPDF
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM,AutoModelForQuestionAnswering,LlamaTokenizer,LlamaForCausalLM,AutoModelForCausalLM
import torch
import requests
import os
import openai


# Set your Hugging Face API token
API_TOKEN=os.getenv("HUGGINGFACE_API_KEY")

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}"
}
MODEL_NAME = "meta-llama/Llama-3.2-1B"

# # Load the tokenizer and model
# model_name = "distilbert-base-uncased-distilled-squad"  # Lightweight model for QA
# tokenizer = AutoTokenizer.from_pretrained(model_name)
# model = AutoModelForQuestionAnswering.from_pretrained(model_name)

# model_name = "EleutherAI/gpt-neo-2.7B"  # Change this to your desired model
# tokenizer = AutoTokenizer.from_pretrained(model_name)
# model = AutoModelForCausalLM.from_pretrained(model_name)

# model_name = "bert-large-uncased-whole-word-masking-finetuned-squad"
# tokenizer = AutoTokenizer.from_pretrained(model_name)
# model = AutoModelForQuestionAnswering.from_pretrained(model_name)

# # Load the StableLM tokenizer and model
# model_name = "StableLM/stablelm-tuned"  # Change to the specific version you want to use
# tokenizer = AutoTokenizer.from_pretrained(model_name)
# model = AutoModelForCausalLM.from_pretrained(model_name)

# model_name = "meta-llama/Llama-2-7b-hf"
# tokenizer = LlamaTokenizer.from_pretrained(model_name)
# model = LlamaForCausalLM.from_pretrained(model_name)

def extract_text_from_pdf(pdf_file, num_pages=10):
    """Extract text from the first few pages of a PDF file."""
    doc = fitz.open(pdf_file)
    text = ""
    for page_num in range(min(num_pages, len(doc))):
        page = doc.load_page(page_num)
        text += page.get_text("text")
    doc.close()
    return text

## using hugging face
def answer_question(question, context):
    """Ask a question to the model using the Hugging Face API."""
    payload = {
        "inputs": f"Context: {context}\nQuestion: {question}",
        "options": {"use_cache": False}
    }

    response = requests.post(f"https://api-inference.huggingface.co/models/{MODEL_NAME}", headers=HEADERS, json=payload)
    
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": response.text}
    

## using openai
def ask_gpt(question:str,book_text:str):
    response=openai.chat.completions.create(
        model="gpt-3.5-turbo-16k",
        messages=[
            {"role":"system","content":"You are a helful tutor who answers the questions based on the book content."},
            {"role":"user","content":f"Here is some content from the book:{book_text}"},
            {"role":"user","context":f"Question:{question}"}

        ],
        max_tokens=1000)
    
    return response['choices'][0]['message']['content'].strip() 


# def answer_question(question, context):
#     """Use the model to answer a question based on the context."""
#     # Prepare the input for the model
#     input_text = f"Question: {question}\nContext: {context}\nAnswer:"
#     inputs = tokenizer(input_text, return_tensors="pt", truncation=True, max_length=512)

#     # Generate the answer
#     with torch.no_grad():
#         outputs = model.generate(inputs["input_ids"], max_length=100, num_return_sequences=1)

#     # Decode the answer
#     answer = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
#     return answer.strip()